package com.hilesorgu.tarayici

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.*
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

val KEYWORDS = """
doomsday,cheat,hack,hacked,inject,injector,loader,aimbot,triggerbot,trigger bot,wallhack,esp,radar,norecoil,no recoil,spoofer,hwid,bypass,executor,krnl,synapse,cheat engine,cheatengine,x64dbg,processhacker,wurst,meteor client,impact client,aristois,liquidbounce,vape,rise client,novoline,tenacity,rusherhack,futureclient,future client,salhack,phobos,konas,3arthh4ck,killaura,kill aura,autoclicker,auto clicker,xray,x-ray,freecam,ghost client,ghostclient,hile,hileci,aim assist,aimassist,slinky,drip client,raven b,nursultan,liquid bounce,thunderhack,wexside,celestial,expensive client,akrien,deadcode,excellent client,wild client,wildclient,minced,dark client,troxill,arbuz,ares client,wurst imperium,rusher hack,gamesense,sal hack,kamiblue,kami blue,lambda client,pyro client,sigma client,moon client,exhibition client,flux client,remix client,jigsaw client,zeroday,astolfo,augustus,intent client,entropy client,gravity client,huzuni,inertia client,jello client,kryptonite,nodus,omikron,wolfram client,wizardhax,bleachhack,bleach hack,cosmos client,coffee client,fusion client,hanabi,hydra client,pandora client,hypnotic client,sentinel client,aether client,aurora client,azura,cyanide client,darkside client,delta client,eternity client,ethereal client,fate client,icarus client,impulse client,ghost clicker,spartan client,orion client,phantom client,venom client,vortex client,zenith client,zephyr client,horion,packet client,onix hack,prax client,nitr0,toolbox hack,mushroom client,seppuku,forgehax,forge hax,xulu,double clicker,jitter click,butterfly click,fast bridge,ghost bridge,scaffold,reach hack,reach,hitbox,anti knockback,antikb,velocity hack,velocity,tracer hack,nuker,fly hack,speed hack,bhop,bunny hop,auto totem,autototem,crystal aura,crystalaura,anchor aura,auto crystal,auto armor,auto pot,autopot,chest stealer,cheststealer,inventory cleaner,fullbright,full bright,gamma,nightvision,night vision,tracers,nametags,chams,glow esp,storage esp,autofish,auto fish,autoeat,auto eat,autowalk,autosprint,nofall,no fall,noslow,no slow,jesus,waterwalk,step hack,spider,phase,blink,timer hack,antiafk,autoclick,clickaura,criticals,teleport hack,elytrafly,baritone,meteor,freelook,zoom hack,bowaimbot,offhand,autoreplenish,fastplace,fast place,fastbreak,fast break,tpaura,safewalk,noclip,antihunger,packetfly,elytra boost,mixin inject,ghost,modmenu hack,speedmine,fastuse,autominer,autobuild,autosoup,autoarmor,autosign,antiblind,antiwobble,noweb,airjump,longjump,highjump,glide,parkour,derp,fakeplayer,fakelag,lagback,reachaura,wallclip,xraymod,oreesp,entityesp,playeresp,boxesp,skeleton esp,hud hack,keystrokes hack,cps hack,macro,aimlock,silent aim,spinbot,antiaim,bunnyhop,wall hack,rapid fire,rapidfire,godmode,god mode,infinite ammo,unlimited ammo,speedhack,noclip hack,teleport,magnet,magnet hack
""".split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }.distinct()

val TEXT_EXT = setOf("txt","log","json","cfg","conf","config","properties","yml","yaml","xml","ini","toml","csv","md","lang","mcmeta","html","htm","js","bat","cmd","ps1","sh")
val ZIP_EXT = setOf("jar","zip","mcpack","mcaddon","litemod","disabled")
val SKIP_MAGIC = setOf("png","jpg","jpeg","gif","webp","bmp","ico","svg","mp3","mp4","ogg","wav","mkv","avi","mov","pdf","docx","xlsx","pptx","apk","ttf","otf","woff","woff2","mca","mcr","nbt","exe","msi","iso","7z","rar","gz","dll")
const val MAX_TEXT = 40L * 1024 * 1024
const val MAX_JAR = 120L * 1024 * 1024
val INFO_RE = Regex("(fabric\\.mod\\.json|quilt\\.mod\\.json|mcmod\\.info|mods\\.toml|plugin\\.yml|bungee\\.yml|\\.mixins\\.json|pack\\.mcmeta)$")
val SEP = Regex("[-_.+$/\\\\]+")
val CAMEL1 = Regex("([a-z0-9])([A-Z])")
val CAMEL2 = Regex("([A-Z]+)([A-Z][a-z])")

class Matcher(val k: String) {
    private val re = if (k.length <= 5) Regex("(^|[^a-z0-9])" + Regex.escape(k) + "([^a-z0-9]|$)") else null
    val c = k.filter { it in 'a'..'z' || it in '0'..'9' }
    fun test(t: String) = if (re != null) re.containsMatchIn(t) else t.contains(k)
}

class Scanner {
    val ms = KEYWORDS.map { Matcher(SEP.replace(it.lowercase(), " ").trim()) }.filter { it.k.isNotEmpty() }
    val contentMs = ms.filter { it.c.length >= 4 }

    fun matches(text: String): List<String> {
        val a = SEP.replace(text.lowercase(), " ")
        val b = SEP.replace(text.replace(CAMEL1, "$1 $2").replace(CAMEL2, "$1 $2").lowercase(), " ")
        return ms.filter { it.test(a) || it.test(b) }.map { it.k }
    }

    private fun readLimited(ins: InputStream, max: Int): ByteArray {
        val bo = ByteArrayOutputStream()
        val buf = ByteArray(16384)
        var total = 0
        while (total < max) {
            val n = ins.read(buf, 0, minOf(buf.size, max - total))
            if (n < 0) break
            bo.write(buf, 0, n); total += n
        }
        return bo.toByteArray()
    }

    fun scanZip(ins: InputStream, label: String, depth: Int, out: MutableList<String>, weak: MutableList<String>): Boolean {
        val pre = if (depth > 0) "[$label] " else ""
        var classes = 0; var short = 0; var any = false
        val seen = HashSet<String>()
        try {
            val zis = ZipInputStream(ins)
            var e = zis.nextEntry
            while (e != null) {
                any = true
                val name = e.name; val low = name.lowercase()
                if (out.size < 25) {
                    val m = matches(name)
                    if (m.isNotEmpty()) {
                        val key = m.joinToString(",") + "|" + name.substringBeforeLast('/', "")
                        if (seen.add(key)) out.add(pre + "Jar içi ad: $name [" + m.joinToString(", ") + "]")
                    }
                }
                if (low.endsWith(".class")) {
                    classes++
                    val b = name.substringAfterLast('/').removeSuffix(".class").substringBefore('$')
                    if (b.length <= 2) short++
                    if (out.size < 25) {
                        val d = readLimited(zis, 2 * 1024 * 1024)
                        val t = String(d, Charsets.ISO_8859_1).lowercase().filter { it.isLetterOrDigit() }
                        val hit = contentMs.filter { t.contains(it.c) }.map { it.k }
                        if (hit.isNotEmpty()) out.add(pre + "Class içeriği: $name [" + hit.joinToString(", ") + "]")
                    }
                } else if (INFO_RE.containsMatchIn(low) && out.size < 25) {
                    val m = matches(String(readLimited(zis, 1024 * 1024), Charsets.UTF_8))
                    if (m.isNotEmpty()) out.add(pre + "Mod bilgisi: $name [" + m.joinToString(", ") + "]")
                } else if (low.endsWith(".jar") && depth < 2) {
                    val d = readLimited(zis, 60 * 1024 * 1024)
                    scanZip(ByteArrayInputStream(d), name.substringAfterLast('/'), depth + 1, out, weak)
                }
                e = zis.nextEntry
            }
        } catch (_: Exception) {}
        if (classes >= 30 && short * 100 / classes > 60)
            weak.add(pre + "Sınıfların %" + (short * 100 / classes) + "'i 1-2 harfli (obfuscate edilmiş olabilir)")
        return any
    }

    class Hit(val path: String, val strong: List<String>, val weak: List<String>)

    fun scanFile(f: File): Hit? {
        val path = f.absolutePath
        val ext = f.extension.lowercase()
        val strong = ArrayList<String>(); val weak = ArrayList<String>()
        val nh = matches(path)
        if (nh.isNotEmpty()) strong.add("Dosya/klasör adı eşleşti: " + nh.joinToString(", "))
        val size = f.length()
        try {
            val isGz = ext == "gz"
            val textExt = if (isGz) f.nameWithoutExtension.substringAfterLast('.', "").lowercase() else ext
            if (textExt in TEXT_EXT && size <= MAX_TEXT) {
                val ins: InputStream = if (isGz) GZIPInputStream(FileInputStream(f)) else FileInputStream(f)
                var n = 0; var shown = 0
                ins.bufferedReader().use { r ->
                    while (shown < 15) {
                        val line = r.readLine() ?: break
                        n++
                        if (line.isEmpty()) continue
                        val m = matches(line)
                        if (m.isNotEmpty()) { shown++; strong.add("Satır $n [" + m.joinToString(", ") + "]: " + line.take(220)) }
                    }
                }
            }
        } catch (_: Throwable) {}
        try {
            if (size in 23..MAX_JAR) {
                var cand = ext in ZIP_EXT; var disguised = false
                if (!cand && ext !in TEXT_EXT && ext !in SKIP_MAGIC) {
                    FileInputStream(f).use { s ->
                        val h = ByteArray(4)
                        if (s.read(h) == 4 && h[0] == 0x50.toByte() && h[1] == 0x4b.toByte() && h[2] == 3.toByte() && h[3] == 4.toByte()) { cand = true; disguised = true }
                    }
                }
                if (cand) {
                    val out = ArrayList<String>(); val wk = ArrayList<String>()
                    val ok = FileInputStream(f).buffered().use { scanZip(it, f.name, 0, out, wk) }
                    if (ok) {
                        if (disguised && (out.isNotEmpty() || wk.isNotEmpty())) strong.add("Uzantı .${ext.ifEmpty { "yok" }} ama içi jar/zip: gizlenmiş olabilir")
                        strong.addAll(out); weak.addAll(wk)
                    }
                }
            }
        } catch (_: Throwable) {}
        return if (strong.isEmpty() && weak.isEmpty()) null else Hit(path, strong, weak)
    }
}

class MainActivity : Activity() {
    private lateinit var btn: Button
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    @Volatile private var running = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 96, 32, 32) }
        val title = TextView(this).apply { text = "Hile Tarayıcı"; textSize = 24f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val sub = TextView(this).apply { text = "Tüm depolamayı (dosya adları, loglar, jar/zip içleri) hile kelimeleri için tarar. Her şey cihazda kalır."; setPadding(0, 8, 0, 24) }
        btn = Button(this).apply { text = "TÜM CİHAZI TARA"; textSize = 20f; setPadding(0, 40, 0, 40); setOnClickListener { start() } }
        status = TextView(this).apply { setPadding(0, 24, 0, 12) }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this).apply { addView(results) }
        root.addView(title); root.addView(sub); root.addView(btn); root.addView(status)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun start() {
        if (running) return
        if (!hasAccess()) {
            if (Build.VERSION.SDK_INT >= 30) {
                Toast.makeText(this, "Açılan ekranda Claude yerine 'Hile Tarayıcı' için izni aç, sonra geri dön ve tekrar bas", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            } else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            return
        }
        running = true; btn.isEnabled = false; results.removeAllViews()
        Thread {
            val sc = Scanner()
            val roots = ArrayList<File>()
            roots.add(Environment.getExternalStorageDirectory())
            File("/storage").listFiles()?.forEach { if (it.name != "emulated" && it.name != "self" && it.canRead()) roots.add(it) }
            val report = StringBuilder(); var count = 0; var hits = 0
            for (r in roots) {
                r.walkTopDown().onFail { _, _ -> }.forEach { f ->
                    if (f.isFile) {
                        count++
                        val h = try { sc.scanFile(f) } catch (_: Throwable) { null }
                        if (h != null) { hits++; report.append(h.path).append('\n'); (h.strong + h.weak).forEach { report.append("   ").append(it).append('\n') }; show(h) }
                        if (count % 25 == 0) runOnUiThread { status.text = "Taranıyor: $count dosya, $hits eşleşme\n" + f.parent }
                    }
                }
            }
            var saved = ""
            try {
                val o = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "hile_tarama_raporu.txt")
                o.writeText(report.toString()); saved = "\nRapor: Download/hile_tarama_raporu.txt"
            } catch (_: Throwable) {}
            runOnUiThread {
                status.text = "Bitti. $count dosya tarandı, $hits dosyada eşleşme bulundu.$saved"
                if (hits == 0) results.addView(TextView(this).apply { text = "Temiz: eşleşen bir şey bulunamadı."; setTextColor(Color.parseColor("#2e9e5b")) })
                btn.isEnabled = true; running = false
            }
        }.start()
    }

    private fun show(h: Scanner.Hit) = runOnUiThread {
        val tv = TextView(this).apply {
            setTextIsSelectable(true)
            setPadding(16, 12, 16, 12)
            val sb = StringBuilder(h.path)
            h.strong.forEach { sb.append("\n• ").append(it) }
            h.weak.forEach { sb.append("\n⚠ Zayıf işaret: ").append(it) }
            text = sb
            setTextColor(if (h.strong.isNotEmpty()) Color.parseColor("#e5484d") else Color.parseColor("#e0a030"))
            textSize = 13f
        }
        results.addView(tv)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(c, p, g)
        if (hasAccess()) start()
    }
}
